import type { AnyDataset, SelectionAudit } from '../shared/contracts';
import { isJiraDataset } from '../shared/contracts';
import { dateTime } from '../shared/calendar';
export function SelectionDetails({ audit }: { audit: SelectionAudit }) {
  return <details className="warnings"><summary>Отбор: включено {new Set(audit.entries.filter(e => e.decision === 'included').map(e => e.issueId)).size} · кандидатов {audit.entries.filter(e => e.decision !== 'invalid').length} · дубликатов {audit.duplicates} · {audit.eligibilityCoverage === 'complete' ? 'признаки проверены' : 'не все признаки проверены'}</summary><ul>{audit.entries.map((entry, i) => <li key={i}>{entry.key ?? entry.requestedKey ?? 'Строка'}{entry.rows.length ? ` · строки ${entry.rows.join(', ')}` : ''}: {entry.reason}</li>)}</ul></details>;
}
export function DatasetSummary({ dataset }: { dataset: AnyDataset }) {
  if (!isJiraDataset(dataset)) return <div className="source-line"><span>{dataset.source.filename} · лист «{dataset.source.sheet}» · сохранённый автономный набор</span><span>Строк: {dataset.source.totalRows} · исключено DF: {dataset.source.excludedDF} · отклонено: {dataset.source.excludedRejected} · некорректных: {dataset.source.invalidRows} · дубликатов: {dataset.source.duplicates}</span></div>;
  const source = dataset.source;
  const label = source.kind === 'file' ? `${source.filename}${source.sheet ? ` · лист «${source.sheet}»` : ''}` : source.kind === 'board' ? `Доска ${source.boardName} · ${source.boardId}` : `Эпик ${source.key}`;
  return <><div className="source-line"><span>{label} · история Jira</span><span>Загружено {dateTime(dataset.syncFinishedAt)} МСК · {dataset.quality === 'complete' ? 'данные полные' : 'данные частичные'}</span></div><SelectionDetails audit={dataset.audit} />{!dataset.epics.length && <div className="notice">{dataset.audit.eligibilityCoverage === 'complete' ? 'В подтверждённой выборке нет подходящих HF-эпиков. Причины приведены в отборе.' : 'Не удалось проверить всех кандидатов. Среди проверенных подходящих HF-эпиков нет; причины приведены в отборе.'}</div>}</>;
}
