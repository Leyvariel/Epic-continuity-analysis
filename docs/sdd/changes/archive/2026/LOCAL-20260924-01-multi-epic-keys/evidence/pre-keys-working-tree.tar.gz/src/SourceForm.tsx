import { useState } from 'react';
export type SourceInput = { kind: 'file'; file: File } | { kind: 'board' | 'epic'; url: string } | { kind: 'refresh'; datasetId: string };
export function SourceForm({ busy, onSubmit }: { busy: boolean; onSubmit: (input: SourceInput) => Promise<void> }) {
  const [kind, setKind] = useState<'file' | 'board' | 'epic'>('file');
  const [url, setUrl] = useState('');
  return <section className="source-form" aria-label="Источник эпиков">
    <div className="source-tabs">{([['file', 'Файл'], ['board', 'Доска Jira'], ['epic', 'Эпик Jira']] as const).map(([value, label]) => <button key={value} type="button" disabled={busy} aria-pressed={kind === value} onClick={() => { setKind(value); setUrl(''); }}>{label}</button>)}</div>
    <form onSubmit={event => { event.preventDefault(); if (!busy && kind !== 'file' && url.trim()) void onSubmit({ kind, url: url.trim() }); }}>
      {kind === 'file' ? <label>CSV или XLSX — достаточно колонки ключей<input type="file" accept=".csv,.xlsx" disabled={busy} aria-label="Файл CSV или XLSX" onChange={event => { const file = event.currentTarget.files?.[0]; if (file && !busy) void onSubmit({ kind: 'file', file }); event.currentTarget.value = ''; }} /></label>
        : <><label htmlFor="source-url">{kind === 'board' ? 'Ссылка на Jira-доску' : 'Ссылка на эпик Jira'}</label><div className="source-url"><input id="source-url" type="url" required value={url} disabled={busy} placeholder={kind === 'board' ? 'https://hq.tutu.ru/secure/RapidBoard.jspa?rapidView=…' : 'https://hq.tutu.ru/browse/KEY-123'} onChange={event => setUrl(event.target.value)} /><button className="primary" disabled={busy || !url.trim()}>Загрузить</button></div></>}
    </form><p>Актуальные признаки HF и история этапов загружаются из Jira. Отклонённые эпики исключаются.</p>
  </section>;
}
