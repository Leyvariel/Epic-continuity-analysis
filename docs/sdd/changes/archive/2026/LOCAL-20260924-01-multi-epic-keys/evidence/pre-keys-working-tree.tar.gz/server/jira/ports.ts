import type { Candidate, HistorySnapshot } from '../../shared/contracts';

/** Values here must be resolved by a verified version-specific adapter, never guessed by the UI. */
export interface JiraIssue {
  id: string; key: string; title: string; flow: 'HF' | 'DF' | 'unknown'; isEpic: boolean;
  resolution: string; currentStatus: string; created: string; updated: string;
  currentStatusId?: string;
  assignee: string; issueType: string;
}
export interface BoardSelection {
  id: string; name: string; fingerprint: string; complete: boolean;
  candidates: Candidate[];
}
export interface JiraGateway {
  getIssue(idOrKey: string, signal: AbortSignal): Promise<JiraIssue>;
  getHistory(issue: JiraIssue, signal: AbortSignal): Promise<HistorySnapshot>;
  readBoard(id: string, signal: AbortSignal): Promise<BoardSelection>;
  close?(): void;
}
export type GatewayFactory = (signal: AbortSignal) => Promise<JiraGateway>;
